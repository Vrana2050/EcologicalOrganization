package rs.ac.uns.acs.nais.TimeseriesDatabaseService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeseriesDatabaseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
